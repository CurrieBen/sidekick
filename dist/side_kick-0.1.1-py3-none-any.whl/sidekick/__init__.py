default_app_config = 'sidekick.apps.SidekickConfig'
